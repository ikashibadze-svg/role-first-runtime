Triton kernel templates go here.
