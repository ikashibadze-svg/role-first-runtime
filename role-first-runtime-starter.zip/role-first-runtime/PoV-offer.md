# 2‑Week PoV Offer (copy/paste)

**We optimize your memory-bound GPU pipeline by ≥15% in 2 weeks—or it’s free.**  
If successful, fee = **25% of verified savings** for 6–12 months (or a flat **$15k**).  
Zero-code install: **LD_PRELOAD + policy.yaml**. We provide before/after charts and an auditable evidence log.

**Contact:** <your email/phone>
