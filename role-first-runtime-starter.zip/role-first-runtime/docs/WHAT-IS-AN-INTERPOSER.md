# What is an interposer? (non-technical)

Think of it as a **universal adapter**. Your program talks to the GPU through a library.
The interposer sits in the middle and **applies smart settings** without changing your app.

You only need to have your engineer build it; you don't write code.
